import numpy as np
import matplotlib.pyplot as plt
import math as m
import pandas as pd
from data7703_Group_project import pooling
import os

def image_show(image):
    size = round(m.sqrt(image.shape[0]))
    image = image.reshape(size, size)
    plt.imshow(image, cmap='gray')
    plt.show()

def image_trans(image):
    size = round(m.sqrt(image.shape[0]))
    image = image.reshape(size, size)
    return image

def mean_image(images):
    mean = np.mean(images, axis=0)
    return mean

def de_mean_images(images):
    mean_vec = mean_image(images)
    demean_images = images - mean_vec
    return demean_images


def eign(demean_matrix, num = 5):
    """return the top eigenvectors of the given matrix."""
    # get the scatter matrix.
    covar = np.cov(demean_matrix, rowvar=False)
    scatter_matrix = (len(demean_matrix) - 1) * covar

    vals, vecs = np.linalg.eig(scatter_matrix)
    vals, vecs = vals[0:num], vecs[:, 0:num].T
    vals_real = np.real(vals)
    vecs_real = np.real(vecs)

    return vals_real, vecs_real

def get_proj(data, eign_vecs):
    """return the projection matrix of the given data in the given eigenvector basis."""
    return data.dot(eign_vecs.T)

def predict_label(train_pca, test_vec_pca, train_labels):
    """return the predicted label of the given test object with the concern of the training data."""
    # compute the euclidean distance.
    distance_matrix = train_pca - test_vec_pca
    distance = np.diag(np.dot(distance_matrix,distance_matrix.T))

    index = np.where(distance == np.min(distance))
    label = train_labels[index]

    return label, index[0][0]

def confusion_matrix(train_data, test_data, eign_basis, train_labels, test_labels):
    """return the recognition rate of the test data."""
    # initialization
    test_num = len(test_data)
    train_pca = get_proj(train_data, eign_basis)
    test_pca = get_proj(test_data, eign_basis)

    # get the predicted labels for the test data.
    prediction_labels = np.zeros((1, test_num))
    for i in range(0, test_num):
        label, index = predict_label(train_pca, test_pca[i], train_labels)
        prediction_labels[0][i] = label

    # compare the predicted labels with the test labels and get the recognition rate.
    o_o, o_t, t_o, t_t= 0,0,0,0
    for i in range(0,test_num):
        if prediction_labels[0][i] == 1:
            if test_labels[i] == 1:
                o_o += 1
            else:
                o_t += 1
        else:
            if test_labels[i] == 1:
                t_o += 1
            else:
                t_t += 1

    matrix = np.array([[o_o, o_t], [t_o, t_t]])
    accuracy = (o_o + t_t)/(o_o+o_t+t_o+t_t)
    return matrix, accuracy


def principal_show(images):
    demean_images = de_mean_images(images)
    vals, vecs = eign(demean_images, 4)
    plt.figure(figsize=(12,12))
    for i in range(4):
        plt.subplot(2, 2, i + 1)
        plt.title("Principal component " + str(i+1))
        plt.imshow(image_trans(vecs[i]), cmap='gray')
    plt.show()

def load(filename, pool_size=37):
    images = []
    for f in os.listdir(filename):
        if not os.path.isdir(f):
            path = os.path.join(filename, f)
            image = np.load(path)
            image = pooling(image, (pool_size, pool_size), pool_size)
            x, y = image.shape
            image = image.reshape((1, x * y))[0]
            images.append(image)
    images = np.array(images)

    return images

def load_label(filename):
    label = pd.read_csv(filename, delimiter=',')
    label = label["label"].values
    return label

def principle_component_test(train_images, test_images, train_labels, test_labels):
    # principle_component_vals = range(1,300)[1:-1:8]
    principle_component_vals = range(1,50)
    principle_components = len(principle_component_vals)
    accuracy_vals = np.zeros(principle_components)

    for i in range(principle_components):
        p_val = principle_component_vals[i]
        vals, vecs = eign(train_images, p_val)
        confusionmatrix, accuracy = confusion_matrix(train_images, test_images, vecs, train_labels, test_labels)
        accuracy_vals[i] = accuracy

    plt.plot(principle_component_vals, accuracy_vals)
    plt.xlabel("The number of principle components")
    plt.ylabel("Accuracy")
    plt.show()

def pool_size_test(n_principle_component=30):

    # pool_sizes = np.array([25,30,35,40,45,50])
    pool_sizes = np.array(range(35,60)[0:-1:2])
    n_pool = len(pool_sizes)
    accuracys = np.zeros(n_pool)

    for i in range(n_pool):
        pool_size = pool_sizes[i]
        train_images = load("F:/UQ_file/data7703/new/11.7version/train", pool_size)
        test_images = load("F:/UQ_file/data7703/new/11.7version/test", pool_size)
        train_labels = load_label("F:/UQ_file/data7703/new/11.7version/train.csv")
        test_labels = load_label("F:/UQ_file/data7703/new/11.7version/test.csv")
        vals, vecs = eign(train_images, n_principle_component)
        confusionmatrix, accuracy = confusion_matrix(train_images, test_images, vecs, train_labels, test_labels)
        accuracys[i] = accuracy

    plt.plot(pool_sizes, accuracys)
    plt.xlabel("pool_size")
    plt.ylabel("accuracys")
    plt.title("The test accuracy against pool-size")
    plt.show()

def main():
    train_images = load("F:/UQ_file/data7703/new/11.7version/train", pool_size=53)
    test_images = load("F:/UQ_file/data7703/new/11.7version/test", pool_size=53)
    train_labels = load_label("F:/UQ_file/data7703/new/11.7version/train.csv")
    test_labels = load_label("F:/UQ_file/data7703/new/11.7version/test.csv")

    # principle_component_test(train_images, test_images, train_labels, test_labels)
    # pool_size_test(n_principle_component=7)

    # principal_show(train_images)

    vals, vecs = eign(train_images, 7)
    confusionmatrix, accuracy = confusion_matrix(train_images, test_images, vecs, train_labels, test_labels)
    print(confusionmatrix)
    print(accuracy)


if __name__ == '__main__':
    main()
