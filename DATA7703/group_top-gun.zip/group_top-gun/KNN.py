import sys
sys.setrecursionlimit(1000000)
import os
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.decomposition import PCA 
from sklearn.neighbors import KNeighborsClassifier 
from sklearn.metrics import confusion_matrix


def load_npydata(filepath, filename):
    x = np.load(filepath+filename,mmap_mode = 'r')
    return x

def KNN(train_pca,train_labels,test_pca,test_labels,k):
    knn=KNeighborsClassifier(n_neighbors=k)
    knn.fit(train_pca,train_labels)
    return knn.score(test_pca, test_labels),knn.predict(test_pca)

def resize(array,ratio):
    width = array.shape[0]
    hight = array.shape[1]
    img = Image.fromarray(array)
    imgr =  img.resize( (int(width*ratio) , int(hight*ratio)), Image.ANTIALIAS)
    a = np.array(imgr)
    return a

def zip(npy_array,ratio):
    r_npy_array = []
    for i in npy_array:
        img_array200 = resize(i, ratio)
        r_npy_array.append(img_array200)
    r_npy_array = np.array(r_npy_array)
    return r_npy_array


def create_dataset(filepath):
    files=os.listdir(filepath)
    number=[]
    npy_array= []
    for i in files:
        npy_array.append(load_npydata(filepath, i))
    return npy_array

def create_labels(filename):
    df=pd.read_excel(filename)
    return df["label"].values
   
'''   
def draw_picture(x,train_data_array,labels_train,test_data_array,labels_test,k=2):
    
    y=[]
    predict=[]
    for i in x:
        train_data=zip(train_data_array,i)
        row,width,height=train_data.shape
        train_data=train_data.reshape(row,width*height)
        
        test_data=zip(test_data_array,i)
        row,width,height=test_data.shape
        test_data=test_data.reshape(row,width*height)
        
        knn_score,knn_predict=KNN(train_data,labels_train,test_data,labels_test,k)
        y.append(knn_score)
        predict.append(knn_predict)
        
    plt.plot(x, y)
    plt.show()
    return np.array(predict)
    
'''    

    
def draw_k_pictures(k_values,train_data_array,labels_train,test_data_array,labels_test):
    y=[]
    predict=[]
    for k in k_values:
        train_data=zip(train_data_array,0.1)
        row,width,height=train_data.shape
        train_data=train_data.reshape(row,width*height)
        
        test_data=zip(test_data_array,0.1)
        row,width,height=test_data.shape
        test_data=test_data.reshape(row,width*height)
        
        knn_score,knn_predict=KNN(train_data,labels_train,test_data,labels_test,k)
        
        y.append(knn_score)
        predict.append(knn_predict)
        
    plt.plot(k_values, y)
    plt.show()
    return np.array(predict)
    
    
    

labels_train=create_labels("train.xlsx")
labels_test=create_labels("test.xlsx")

train=create_dataset("train/")
train=np.array(train)
test=create_dataset("test/")
test=np.array(test)

#x=[i/20 for i in range(1,10)]#ratio
k_values=[i for i in range(1,3)]#k_values

y_true=labels_test

#y_predict=draw_picture(x,train,labels_train,test,labels_test)

yk_predict=draw_k_pictures(k_values,train,labels_train,test,labels_test)

#打印混淆矩阵

for i in yk_predict:
    print(confusion_matrix(y_true, i))
