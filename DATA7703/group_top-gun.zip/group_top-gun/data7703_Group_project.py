import numpy as np
import matplotlib.pyplot as plt

x_filter = np.array([[-1,0,1],[-2,0,2],[-1,0,1]])*0.5
y_filter = np.array([[-1,-2,-1],[0,0,0],[1,2,1]])*0.5
Smooth = np.array([[1,2,1],[2,8,2],[1,2,1]])/20
# sample_image = np.array([[1,2,3,4,5,6],[7,8,9,10,11,12],[13,14,15,16,17,18],[19,20,21,22,23,24],[25,26,27,28,29,30],[31,32,33,34,35,36]])


image = np.load("A_Hour_146_Band_09.npy")

def convolution(image, filter, step):
    """Implementing the edge detection in convolution.
        input: image<(2000,2000)>: the nparray containing the information of the image
                filter <np.array>: the small filter matrix.
                step: the step the window should jump.
        return: edge_image <nparray>: the edge image."""
    len_y, len_x = image.shape
    filter_y, filter_x = filter.shape
    if len_x % step != 0:
        edge_image_x = (len_x - filter_x)//step + 1
        edge_image_y = (len_y - filter_y)//step + 1
    else:
        edge_image_x = (len_x - filter_x//step) - 1
        edge_image_y = (len_y - filter_y//step) - 1
    edge_image = np.zeros((edge_image_x,edge_image_y))
    for i in range(len_y-filter_y)[0:-1:step]:
        for j in range(len_x - filter_x)[0:-1:step]:
            window = np.zeros((filter_x, filter_y))
            for k in range(filter_x):
                window[k,] = image[i, j:j+filter_x]
            value = window * filter
            value = value.sum()
            edge_image[i//step][j//step] = value

    return edge_image

def normalize(image, scale):
    """normalize the numbers in the image to range(0,255)."""
    image_max = image.max()
    image_min = image.min()
    result = (image - image_min)/(image_max - image_min) * scale
    return result

def pooling(image, filter_size, step, state = "max"):
    len_y, len_x = image.shape
    filter_y, filter_x = filter_size
    if len_x % step != 0:
        pool_image_x = (len_x - filter_x) // step + 1
        pool_image_y = (len_y - filter_y) // step + 1
    else:
        pool_image_x = len_x//step - 1
        pool_image_y = len_y//step - 1
    pool_image = np.zeros((pool_image_x, pool_image_y))
    for i in range(len_y - filter_y)[0:-1:step]:
        for j in range(len_x - filter_x)[0:-1:step]:
            window = np.zeros((filter_x, filter_y))
            for k in range(filter_x):
                window[k,] = image[i, j:j + filter_x]
            if state == "max":
                value = np.max(window)
            elif state == "avg":
                value = np.mean(window)
            pool_image[i//step][j//step] = value

    return pool_image

def edge_show(image, step, size=6, x_filter=x_filter, y_filter=y_filter):
    """Show the edge of the image and the original image in a 2X2 format."""
    image_edge_x = convolution(image, x_filter, step)
    image_edge_y = convolution(image.T, x_filter, step).T
    image_edge = image_edge_x + image_edge_y

    plt.figure(figsize=(2 * size, 2 * size))
    plt.subplot(2, 2, 1)
    plt.title("original image")
    plt.imshow(image, cmap='gray')
    plt.subplot(2, 2, 2)
    plt.title("edge image")
    plt.imshow(image_edge, cmap='gray')
    plt.subplot(2, 2, 3)
    plt.title("image of edge detecting from x axis")
    plt.imshow(image_edge_x, cmap='gray')
    plt.subplot(2, 2, 4)
    plt.title("image of edge detecting from y axis")
    plt.imshow(image_edge_y, cmap='gray')
    plt.show()

def pooling_show(image, state):
    pool_sizes = [3,7,12,18,25,29,35,40,45]
    plt.figure(figsize=(12,12))
    for i in range(len(pool_sizes)):
        pool_size = pool_sizes[i]
        pool_image = pooling(image, (pool_size, pool_size), pool_size, state)
        plt.subplot(3,3,i+1)
        plt.title("Pooling with pool size "+ str(pool_size))
        plt.imshow(pool_image, cmap='gray')

    plt.show()

def smoothing_show(image):
    smooth_image = convolution(image, Smooth, 1)

    plt.figure(figsize=(6,12))
    plt.subplot(2,1,1)
    plt.title("Before smoothing")
    plt.imshow(image, cmap='gray')
    plt.subplot(2,1,2)
    plt.title("After smoothing")
    plt.imshow(smooth_image, cmap='gray')

    plt.show()

def main():
    edge_show(image, 1)
    pooling_show(image, "max")

    pooled_image_1 = pooling(image, (6, 6), 6)
    edge_show(pooled_image_1, 1)

    pooled_image_2 = pooling(image, (30, 30), 30)
    smoothing_show(pooled_image_2)


if __name__ == '__main__':
    main()